/*
 * Descreva um programa que a partir da distância percorrida 
 * e o do tempo gasto por um motorista durante uma viagem de final de semana, 
 * calcule a velocidade média e a quantidade de combustível gasto na viagem, 
 * sabendo que o automóvel faz 12 km por litro.
 */

import java.text.DecimalFormat;
import java.util.Scanner;

public class Uni3_Exe14 {
    public static void main(String[] args) {

        DecimalFormat df = new DecimalFormat("0.00");

        Scanner input = new Scanner(System.in);
        // Entradas
        System.out.println("Informe a distância percorrida no trajeto (em Km):");
        double distancia = input.nextDouble();
        System.out.println("Informe o tempo gasto no trajeto (em horas):");
        double tempo = input.nextDouble();

        input.close();
        // Processo
        double velocidadeMedia = distancia / tempo;
        double gasolinaGasta = distancia / 12;

        // Saída
        System.out.println(
                "Velocidade média: " + velocidadeMedia + " Gasolina gasta: " + "\n" + df.format(gasolinaGasta));
    }

}
