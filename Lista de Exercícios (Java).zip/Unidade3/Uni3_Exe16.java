/*
 * Suponha que um caixa disponha apenas de notas de 100, 10 e 1 reais. 
 * Considerando que alguém está pagando uma compra, faça um programa que determine 
 * e escreva o número mínimo de notas que o caixa deve fornecer como troco. 
 * Escreva também o número de cada tipo de nota a ser fornecido como troco. 
 * Suponha que o sistema monetário não utilize centavos.
 */

import java.util.Scanner;

public class Uni3_Exe16 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        // Entradas
        System.out.println("Informe o valor da compra:");
        int valor = input.nextInt();
        System.out.println("Informe o valor que você irá pagar:");
        int valorPago = input.nextInt();

        input.close();
        // Processo
        int pagamento = valorPago - valor;
        int centena = pagamento / 100;
        int dezena = (pagamento % 100) / 10;
        int unidade = ((pagamento % 100) % 10);

        // Saídas
        System.out.println("O troco será de: " + centena + " nota(s) de cem " + dezena + " nota(s) de dez " + unidade
                + " moeda(s) de um real ");
    }

}
