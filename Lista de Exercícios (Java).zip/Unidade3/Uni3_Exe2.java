/*
 * Uma loja de calçados está concedendo 12% de desconto nos produtos. 
 * Escreva um programa para calcular e exibir o valor de desconto a ser dado num par de sapatos e 
 * quanto deve custar o produto com o desconto. O preço do par de sapatos deve ser informado pelo usuário. 
 * Como resultado, o programa deverá exibir as seguintes mensagens:

 *O valor do desconto é de R$ xxx
 *O preço do par de sapatos com desconto é R$ xxx
 */

import java.text.DecimalFormat;
import java.util.Scanner;

public class Uni3_Exe2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        DecimalFormat df = new DecimalFormat("0.00");

        // Entradas
        System.out.println("Preço do Sapato: ");
        double precoSapato = input.nextDouble();
        double desconto = 0.12;

        // Processo
        double valorDesconto = precoSapato * desconto;
        double valorTotal = precoSapato - valorDesconto;

        // Saídas
        System.out.println("O valor do desconto é de: R$ " + df.format(valorDesconto));
        System.out.println("O preço do sapato, com o desconto aplicado, é: R$ " + df.format(valorTotal));

        input.close();
    }
}
