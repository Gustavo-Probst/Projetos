/*
 * Uma empresa tem para um funcionário os seguintes dados: 
 * o nome, o número de horas trabalhadas mensais e o número de dependentes. 
 * A empresa paga R$ 10,00 por hora (valor para cálculo do salário trabalho) 
 * e R$ 60,00 por dependente (valor para cálculo do salário família) 
 * e são feitos descontos de 8,5% sobre o salário trabalho para o INSS 
 * e de 5% sobre o salário trabalho para o imposto de renda. 
 * Descreva um programa que informe o nome, o salário bruto e o salário líquido do funcionário.
 */

import java.text.DecimalFormat;
import java.util.Scanner;

public class Uni3_Exe12 {
    public static void main(String[] args) {

        DecimalFormat df = new DecimalFormat("0.00");

        Scanner input = new Scanner(System.in);
        // Entradas
        System.out.println("Informe o nome:");
        String nome = input.nextLine();
        System.out.println("Informe o número de horas trabalhadas mensais:");
        int horas = input.nextInt();
        System.out.println("Informe o número de dependentes:");
        int dependentes = input.nextInt();

        input.close();

        // Processo
        double salarioTrabalho = horas * 10;
        double salarioFamilia = dependentes * 60;
        double desconto = 0.135;
        double salarioLiquido = salarioTrabalho - desconto;
        double salarioBruto = salarioTrabalho + salarioFamilia;

        // Saídas
        System.out.println("Nome: " + nome + " \nSalário Bruto: " + df.format(salarioBruto) + " \nSalário Líquido: "
                + df.format(salarioLiquido));

    }

}
