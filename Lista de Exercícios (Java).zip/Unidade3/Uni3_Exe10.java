/*
 * Descreva um programa que leia o comprimento dos catetos de um triângulo retângulo 
 * e calcule o comprimento da hipotenusa.
 */

import java.util.Scanner;

public class Uni3_Exe10 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        // Entradas
        System.out.println("Informe o cateto 1:");
        double cateto1 = input.nextDouble();
        System.out.println("Informe o cateto 2:");
        double cateto2 = input.nextDouble();

        input.close();

        // Saída
        System.out.println("A hipotenusa é: " + (Math.pow(cateto1, 2) + Math.pow(cateto2, 2)));
    }

}
