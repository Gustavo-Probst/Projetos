/*
*Construa um programa para ler um número inteiro (assuma até 3 dígitos) 
*e imprima a saída da seguinte forma:
*
*X centena(s)  Y dezena(s) K unidade(s)
*
*Exemplo, se for submetido o número 384, o programa deverá exibir:
*
*3 centena(s)  8 dezena(s) 4 unidade(s)  
*/

import java.util.Scanner;

public class Uni3_Exe15 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        // Entradas
        System.out.println("Informe um número:");
        int numero1 = input.nextInt();

        input.close();
        // Processo
        int centena = numero1 / 100;
        int dezena = (numero1 % 100) / 10;
        int unidade = ((numero1 % 100) % 10);

        // Saídas
        System.out.println(centena + " centena(s) " + dezena + " dezena(s) " + unidade + " unidade(s) ");
    }

}
