/*
 * Descreva um programa que dado uma temperatura em °C informe o seu valor em °F.
 */

import java.util.Scanner;

public class Uni3_Exe11 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        // Entradas
        System.out.println("Informe a temperatura (em ºC):");
        float temperatura = input.nextFloat();

        input.close();
        // Processo
        float conversao = (temperatura * 9) / 5 + 32;
        // Saída
        System.out.println("A temperatura (em ºF) é: " + conversao);
    }

}
