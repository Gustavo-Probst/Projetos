/*
 * Descreva um programa que calcule o volume de uma lata de óleo.
 */

import java.util.Scanner;

public class Uni3_Exe9 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        // Entrados
        System.out.println("Informe o raio da lata:");
        double raio = input.nextDouble();
        System.out.println("Informe a altura da lata:");
        double altura = input.nextDouble();

        input.close();
        // Processo
        double volume = Math.PI * Math.pow(raio, 2) * altura;

        // Saída
        System.out.println("A área da lata é: " + volume);

    }

}
