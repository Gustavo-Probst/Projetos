/*
*Uma imobiliária vende apenas terrenos retangulares. 
*Faça um programa para ler as dimensões de um terreno e depois exibir a área do terreno. 
*/

import java.util.Scanner;

public class Uni3_Exe1 {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        // Entradas
        System.out.println("Informe a largura:");
        float largura = input.nextInt();

        System.out.println("Informe o coprimento:");
        float comprimento = input.nextInt();

        // Processo
        float area = largura * comprimento;

        // Saídas
        System.out.println("A área é: " + area);

        input.close();
    }

}