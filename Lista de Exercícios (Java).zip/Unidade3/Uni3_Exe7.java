/*
 * Uma fábrica de refrigerantes vende seu produto em três formatos: 
 * lata de 350 ml, garrafa de 600 ml e garrafa de 2 litros. 
 * Se um comerciante compra uma determinada quantidade de cada formato, 
 * faça um programa para calcular quantos litros de refrigerante ele comprou.
 */

import java.util.Scanner;

public class Uni3_Exe7 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        // Entradas
        System.out.println("Quantos refrigerantes de 350ml você deseja comprar?");
        int refri350 = input.nextInt();
        System.out.println("Quantos refrigerantes de 600ml você deseja comprar?");
        int refri600 = input.nextInt();
        System.out.println("Quantos refrigerantes de 2L você deseja comprar?");
        int refri2L = input.nextInt();

        input.close();
        // Processo
        double litrosTotais = ((refri350 * 0.35) + (refri600 * 0.60) + (refri2L * 2));

        // Saídas
        System.out.println("Você comprou: " + litrosTotais + "L de refrigerante.");
    }

}
