/*
 * Um motorista deseja abastecer seu tanque de combustível. 
 * Escreva um programa para ler o preço do litro da gasolina e o valor do pagamento e 
 * exibir quantos litros ele conseguiu colocar no tanque.
 */

import java.util.Scanner;

public class Uni3_Exe3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Entradas
        System.out.println("Informe o preço da gasolina: ");
        double precoGasolina = input.nextDouble();
        System.out.println("Informe quanto você vai pagar: ");
        double pagamento = input.nextDouble();

        input.close();

        // Processo
        double litrosGasolina = pagamento / precoGasolina;

        // Saídas
        System.out.println("Você abasteceu o seu carro com: " + litrosGasolina + " litros.");
    }
}
