/*
 * Uma pessoa foi até uma casa de câmbio trocar dólares por reais. 
 * Para isto ela entregou um valor em dólares para o atendente. 
 * Considerando que o atendente tem a cotação do dólar, 
 * descreva um programa para calcular quantos reais o atendente deve devolver para a pessoa.
 */

import java.text.DecimalFormat;
import java.util.Scanner;

public class Uni3_Exe8 {
    public static void main(String[] args) {

        DecimalFormat df = new DecimalFormat("0.00");

        Scanner input = new Scanner(System.in);
        // Entradas
        System.out.println("Quantos dólares você deseja trocar? ");
        int dolar = input.nextInt();

        input.close();
        // Processo
        double calculoCotacao = dolar * 5.50;

        // Saídas
        System.out.println("Você receberá: R$ " + df.format(calculoCotacao));

    }

}
