/*
 * Um restaurante cobra R$ 25,00 por cada quilo de refeição. 
 * Escreva um programa que leia o peso do prato montado pelo cliente (em quilos) e imprima o valor a pagar. 
 * O peso do prato é de 750 gramas.
 */

import java.util.Scanner;

public class Uni3_Exe6 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        // Entradas
        System.out.println("Kg do prato montado: ");
        float pratoMontado = input.nextFloat();

        input.close();
        // Processo
        double valorTotal = (pratoMontado - 0.75) * 25;

        // Saídas
        System.out.println("Valor total a pagar: " + valorTotal);

    }

}
