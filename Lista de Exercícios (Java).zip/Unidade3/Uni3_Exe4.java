/*
 * Faça um programa para ler três notas de um aluno em uma disciplina e 
 * imprimir a sua média ponderada (as notas tem pesos respectivos de 5, 3 e 2).
 */

import java.util.Scanner;

public class Uni3_Exe4 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Entradas
        System.out.println("Informe a 1ª nota: ");
        float nota1 = input.nextFloat();
        System.out.println("Informe a 2ª nota: ");
        float nota2 = input.nextFloat();
        System.out.println("Informe a 3ª nota: ");
        float nota3 = input.nextFloat();

        // Processo
        float mediaPonderada = ((nota1 * 5 + nota2 * 3 + nota3 * 2) / 10);

        // Saídas
        System.out.println("A média ponderada das notas é: " + mediaPonderada);

        input.close();
    }

}
