/*
 * Numa loja de materiais de construção, um azulejo estampado custa R$ 12,50. 
 * Faça um programa para ler o comprimento e altura de uma parede (em metros), 
 * e depois escrever o valor gasto com a compra de azulejos. 
 * Considere que um metro quadrado é formado por 9 azulejos.
 */

import java.text.DecimalFormat;
import java.util.Scanner;

public class Uni3_Exe13 {
    public static void main(String[] args) {

        DecimalFormat df = new DecimalFormat("0.00");

        Scanner input = new Scanner(System.in);
        // Entradas
        System.out.println("Informe o comprimento da parede:");
        double comprimento = input.nextDouble();
        System.out.println("Informe a altura da parede:");
        double altura = input.nextDouble();

        input.close();
        // Processo
        double area = comprimento * altura;
        double precoAzulejo = area * 112.50;

        // Saída
        System.out.println("O preço total é: R$" + df.format(precoAzulejo));

    }

}
