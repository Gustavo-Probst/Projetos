/*
 * Dada uma pergunta, “a cor é azul?”, faça um programa que leia uma variável lógica com a resposta 
 * e responda “Sim”, caso a resposta seja true, ou “Não”, caso seja false.
 */

import java.util.Scanner;

public class Uni4Exe05 {
    public static void main(String[] args) {

        // Entradas
        Scanner input = new Scanner(System.in);

        System.out.println("A cor é azul? ");
        String cor = input.nextLine();
        cor = cor.toUpperCase();

        input.close();

        // Processo
        if (cor.equals("SIM") || cor.equals("S")) {
            System.out.println("A cor é azul.");
        } else if (cor.equals("NÃO") || cor.equals("N")) {
            System.out.println("A cor não é azul.");
        } else {
            System.out.println("Não entendi.");
        }

    }
}
