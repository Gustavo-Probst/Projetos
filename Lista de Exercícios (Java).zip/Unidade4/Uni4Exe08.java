/*
 * Dado uma letra, escreva um algoritmo que informe se ela é ou não uma vogal.
 */

import java.util.Scanner;

public class Uni4Exe08 {
    public static void main(String[] args) {

        // Entradas
        Scanner input = new Scanner(System.in);
        System.out.println("Digite uma letra: ");
        char letra = input.next().charAt(0);
        letra = Character.toUpperCase(letra);

        input.close();

        // Processo e Saídas
        if (letra != 'A' && letra != 'E' && letra != 'I' && letra != 'O' && letra != 'U') {
            System.out.println("A letra não é uma vogal.");
        } else {
            System.out.println("A letra é uma vogal.");
        }
    }
}
