/*
 * Um casal possui três filhos: Marquinhos, Zezinho e Luluzinha. 
 * Faça um algoritmo para ler as idades dos filhos e exibir quem é o caçula da família; 
 * suponha que não haja empates.
 */

import java.util.Scanner;

public class Uni4Exe10 {
    public static void main(String[] args) {

        // Entradas
        Scanner input = new Scanner(System.in);
        System.out.println("Digite a idade de Marquinhos: ");
        int idade1 = input.nextInt();
        System.out.println("Digite a idade de Zezinho: ");
        int idade2 = input.nextInt();
        System.out.println("Digite a idade da Luluzinha: ");
        int idade3 = input.nextInt();

        input.close();

        // Processo
        if (idade1 < idade2 && idade1 < idade3) {
            System.out.println("Marquinhos é o caçula da família.");
        } else if (idade2 < idade1 && idade2 < idade3) {
            System.out.println("Zezinho é o caçula da família. ");
        } else {
            System.out.println("Luluzinha é a caçula da família. ");
        }

    }
}
