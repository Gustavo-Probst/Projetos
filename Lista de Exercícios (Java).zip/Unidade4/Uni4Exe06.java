/*
 * Faça um algoritmo que leia um caractere. Caso seja digitada a letra 'M' escreva “Masculino”. 
 * Se for digitada a letra 'F' escreva “Feminino”. Se for informado 'I' escreva “Não Informado”. 
 * Qualquer outra letra digitada escreva “Entrada Incorreta”. 
 * Atenção: antes de testar a letra, converta-a para maiúscula.
 */

import java.util.Scanner;

public class Uni4Exe06 {
    public static void main(String[] args) {

        // Entradas
        Scanner input = new Scanner(System.in);

        System.out.println("Digite a letra correspondente ao seu sexo: ");
        System.out.println("\"M\" para Masculino\n\"F\" para Feminino\n\"I\" para Não Informado\n");
        char sexo = input.next().charAt(0);
        sexo = Character.toUpperCase(sexo);

        input.close();

        // Processo
        if (sexo == 'M') {
            System.out.println("\nMasculino.");
        } else if (sexo == 'F') {
            System.out.println("\nFeminino.");
        } else if (sexo == 'I') {
            System.out.println("\nNão Informado.");
        } else {
            System.out.println("\nEntrada Incorreta.");
        }

    }
}
