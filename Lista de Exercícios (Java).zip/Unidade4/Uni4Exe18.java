/*
 * Uma loja que trabalha com crediário funciona da seguinte maneira: 
 * se o pagamento ocorre até o dia do vencimento, o cliente ganha 10% de desconto 
 * e é avisado que o pagamento está em dia. 
 * Se o pagamento é realizado até cinco dias após o vencimento o cliente perde o desconto, 
 * e se o pagamento atrasa mais de cinco dias, é cobrada uma multa de 2% por cada dia de atraso. 
 * Faça um algoritmo que leia o dia do vencimento, o dia do pagamento e o valor da prestação 
 * e calcule o valor a ser pago pelo cliente, exibindo as devidas mensagens. 
 * Suponha que todo vencimento ocorre até o dia dez de cada mês 
 * e os clientes nunca deixam para pagar no mês seguinte.
 */

import java.text.DecimalFormat;
import java.util.Scanner;

public class Uni4Exe18 {
    public static void main(String[] args) {

        DecimalFormat df = new DecimalFormat("0.00");

        // Entradas
        Scanner input = new Scanner(System.in);
        System.out.println("Informe o dia do pagamento:");
        int diaPagamento = input.nextInt();
        System.out.println("Informe o valor da prestação:");
        double valor = input.nextDouble();

        input.close();

        // Processo e Saídas
        if (diaPagamento <= 10) {
            double desconto = valor * 0.1;
            double valorCorrigido = valor - desconto;
            System.out.println("Valor a ser pago: R$ " + df.format(valorCorrigido));
            System.out.println("\nO pagamento está em dia.");
        } else if (diaPagamento > 10 && diaPagamento <= 15) {
            System.out.println("Valor a ser pago: R$ " + df.format(valor));
        } else if (diaPagamento > 15 && diaPagamento <= 31) {
            double calculo = diaPagamento - 15;
            double juros = calculo * 1.02;
            double valorFinal = valor + juros;
            System.out.println("Valor a ser pago: R$ " + df.format(valorFinal));
        }
    }
}
