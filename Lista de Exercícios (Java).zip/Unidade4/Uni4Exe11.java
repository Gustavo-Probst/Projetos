/*
 * Escreva um algoritmo para ler o ano de nascimento de 3 irmãos, 
 * escrever uma mensagem que indique se eles são TRIGÊMEOS, GÊMEOS, APENAS IRMÃOS. 
 * Considere que eles são GÊMEOS se dois deles possuem a mesma idade e o outro diferente dos demais, 
 * e apenas irmãos se todas as idades forem diferentes.
 */

import java.util.Scanner;

public class Uni4Exe11 {
    public static void main(String[] args) {

        // Entradas
        Scanner input = new Scanner(System.in);
        System.out.println("Digite o ano de nascimento de seu 1º filho(a): ");
        int ano1 = input.nextInt();
        System.out.println("Digite o ano de nascimento de seu 2º filho(a): ");
        int ano2 = input.nextInt();
        System.out.println("Digite o ano de nascimento de seu 3º filho(a): ");
        int ano3 = input.nextInt();

        input.close();

        // Processo
        if (ano1 == ano2 && ano1 == ano3) {
            System.out.println("Seus filhos são trigêmeos.");
        } else if (ano1 == ano2 && ano1 != ano3) {
            System.out.println("Seus filhos são gêmeos.");
        } else if (ano1 != ano2 && ano1 == ano3) {
            System.out.println("Seus filhos são gêmeos.");
        } else {
            System.out.println("Seus filhos são apenas irmãos.");
        }
    }
}
