/*
 * Dadas 3 notas obtidas por um aluno em 3 provas e a média dos exercícios, descreva um algoritmo que calcule a média de aproveitamento e o conceito do aluno, usando a fórmula:

\normalsize&space;media=(notaProva1+notaProva22+notaProva33+notaExercicios)/7

A atribuição dos conceitos obedece à tabela abaixo:

media	conceito
>= 9.0	A
>= 7.5 e < 9.0	B
>= 6.0 e < 7.5	C
>= 4.0 e < 6.0	D
< 4.0	E
O algoritmo deve escrever a média de aproveitamento, o conceito correspondente e a mensagem "aprovado" caso o conceito seja A, B ou C, e "reprovado" caso o conceito seja D ou E.
 */

import java.util.Scanner;

public class Uni4Exe20 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Informe a nota do 1º do exercício:");
        double nota1 = input.nextDouble();
        System.out.println("Informe a nota do 2º do exercício:");
        double nota2 = input.nextDouble();
        System.out.println("Informe a nota do 3º do exercício:");
        double nota3 = input.nextDouble();

        input.close();

        double media = (nota1 + nota2 + nota3) / 3;

        if (media >= 9.0) {
            System.out.println("Conceito: A \nAprovado!");
        } else if (media < 9.0 && media >= 7.5) {
            System.out.println("Conceito: B \nAprovado!");
        } else if (media < 7.5 && media >= 6.0) {
            System.out.println("Conceito: C \nAprovado!");
        } else if (media < 6.0 && media >= 4.0) {
            System.out.println("Conceito: D \nReprovado.");
        } else if (media < 4.0) {
            System.out.println("Conceito: E \nReprovado.");
        }
    }
}
