/*
 * Dado um número de ponto flutuante maior do que 0, 
 * informe se foram digitadas ou não casas decimais no número.
 */

import java.util.Scanner;

public class Uni4Exe04 {
    public static void main(String[] args) {

        // Entradas
        Scanner input = new Scanner(System.in);

        System.out.println("Digite um número (maior que 0): ");
        float numero1 = input.nextFloat();

        input.close();

        // Processo
        if (numero1 > 0 && numero1 != Math.floor(numero1)) {

            // Saídas
            System.out.println("O número é decimal.");
        } else {
            System.out.println("O número é inteiro.");
        }
    }
}
