/*
 * Dados dois valores inteiros, escreva um algoritmo que informe se eles são múltiplos ou não.
 */

import java.util.Scanner;

public class Uni4Exe09 {
    public static void main(String[] args) {
        
        //Entradas
        Scanner input = new Scanner(System.in);

        System.out.println("Digite um número: ");
        float numero1 = input.nextFloat();
        System.out.println("Digite outro número: ");
        float numero2 = input.nextFloat();

        input.close();

        //Processo
        if (numero1 % numero2 == 0 || numero2 % numero1 == 0) {
            
            //Saídas
            System.out.println("O número é múltiplo.");
        } else  {
            System.out.println("O número não é múltiplo.");
        }
    }    
}
