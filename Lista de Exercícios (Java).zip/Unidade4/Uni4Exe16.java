/*
 * Escreva um algoritmo que leia a idade de 2 homens e 2 mulheres 
 * (considere que a idade entre homens e mulheres sempre serão diferentes). 
 * Calcule e escreva a soma das idades do homem mais velho com a mulher mais nova, 
 * e o produto das idades do homem mais novo com a mulher mais velha.
 */

import java.util.Scanner;

public class Uni4Exe16 {
   public static void main(String[] args) {

      // Entradas
      Scanner input = new Scanner(System.in);
      System.out.println("Digite a idade do 1º homem");
      int homem1 = input.nextInt();
      System.out.println("Digite a idade do 2º homem");
      int homem2 = input.nextInt();
      System.out.println("Digite a idade da 1ª mulher");
      int mulher1 = input.nextInt();
      System.out.println("Digite a idade da 2ª mulher");
      int mulher2 = input.nextInt();

      input.close();

      if (homem1 > homem2 && mulher1 > mulher2) {
         int homemVelho = homem1;
         int homemNovo = homem2;
         int mulherVelha = mulher1;
         int mulherNova = mulher2;

         int soma = homemVelho + mulherNova;
         int produto = homemNovo * mulherVelha;

         System.out.println("Soma: " + soma);
         System.out.println("Produto: " + produto);
      } else {
         int homemVelho = homem2;
         int homemNovo = homem1;
         int mulherVelha = mulher2;
         int mulherNova = mulher1;

         int soma = homemVelho + mulherNova;
         int produto = homemNovo * mulherVelha;

         System.out.println("Soma: " + soma);
         System.out.println("Produto: " + produto);
      }

   }
}
