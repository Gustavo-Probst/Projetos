/*
 * Dados 3 valores, escreva um algoritmo que os informe em uma determinada ordem 
 * a partir de um menu de opções:

se opção = 1, escreva os 3 valores em ordem crescente
se opção = 2, escreva os 3 valores em ordem decrescente
se opção = 3, escreva os 3 valores de forma que o maior valor fique no meio
 */

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Uni4Exe24 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Digite um número:");
        int num1 = input.nextInt();
        System.out.println("\nDigite um número:");
        int num2 = input.nextInt();
        System.out.println("\nDigite um número:");
        int num3 = input.nextInt();

        System.out.println("\nO que você deseja?\n1 - Mostrar os 3 valores em ordem crescente\n" +
                "2 - Mostrar os 3 valores em ordem decrescente\n3 - Mostrar os 3 valores de forma que o maior valor fique no meio");
        int opcao = input.nextInt();

        input.close();

        List<Integer> lista = Arrays.asList(num1, num2, num3);

        switch (opcao) {
            case 1:
                Collections.sort(lista);
                System.out.println("\nNúmeros em ordem crescnte: " + lista);
                break;

            case 2:
                Collections.sort(lista, Collections.reverseOrder());
                System.out.println("\nNúmeros em ordem decrescnte: " + lista);
                break;

            case 3:
                if (num1 > num2 && num1 > num3) {
                    System.out.println("\nNúmeros em ordem de forma que o maior valor fique no meio: [" + num2 + ", "
                            + num1 + ", " + num3 + "]");
                } else if (num2 > num1 && num2 > num3) {
                    System.out.println("\nNúmeros em ordem de forma que o maior valor fique no meio: [" + num1 + ", "
                            + num2 + ", " + num3 + "]");
                } else if (num3 > num1 && num3 > num1) {
                    System.out.println("\nNúmeros em ordem de forma que o maior valor fique no meio: [" + num1 + ", "
                            + num3 + ", " + num2 + "]");
                }
                break;

            default:
                System.out.println("\nResposta inválida.");
                break;
        }
    }
}
