/*
 * Faça um algoritmo que escreva o menu abaixo, leia uma opção do usuário e execute a operação correspondente. 
 * O algoritmo deve exibir uma mensagem de erro se a opção for inválida. O menu tem as seguintes opções:
Escolha uma opção:
1 - Soma de dois números.
2 - Diferença entre dois números.
3 - Produto entre dois números.
4 - Divisão entre dois números (o denominador não pode ser zero).
 */

import java.util.Scanner;

public class Uni4Exe25 {
    public static void main(String[] args) {

        // Entradas
        Scanner input = new Scanner(System.in);
        System.out.println("\nDigite um número:");
        double num1 = input.nextDouble();
        System.out.println("\nDigite outro número:");
        double num2 = input.nextDouble();

        System.out.println("\nQual dessas opções você deseja?\n1 - Soma de dois números" +
                "\n2 - Diferença entre dois números\n3 - Produto entre dois números" +
                "\n4 - Divisão entre dois números");
        int opcao = input.nextInt();

        input.close();

        switch (opcao) {
            case 1:
                double soma = num1 + num2;
                System.out.println("Soma de dois números: " + soma);
                break;
            case 2:
                double diferenca = num1 - num2;
                System.out.println("Diferença entre dois números: " + diferenca);
                break;
            case 3:
                double produto = num1 * num2;
                System.out.println("Produto entre dois números: " + produto);
                break;
            case 4:
                if (num2 != 0) {
                    double divisao = num1 / num2;
                    System.out.println("Divisão entre dois números: " + divisao);
                } else {
                    System.out.println("Não é possível dividir por zero. Tente novamente com outro número.");
                }
            default:
                break;
        }
    }
}
