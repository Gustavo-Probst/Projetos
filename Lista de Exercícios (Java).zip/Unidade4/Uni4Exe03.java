/*
 * Dados dois números inteiros descreva um algoritmo para informar o maior valor entre eles.
 */

import java.util.Scanner;

public class Uni4Exe03 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Entradas
        System.out.println("Informe o primeiro número:");
        int numero1 = input.nextInt();

        System.out.println("Informe o segundo número:");
        int numero2 = input.nextInt();
        int maiorNumero;

        // Processo
        if (numero1 == numero2) {
            System.out.println("Números iguais.");
        } else {
            if (numero1 > numero2) {
                maiorNumero = numero1;
            } else {
                maiorNumero = numero2;
            }
            System.out.println(maiorNumero + " é o maior.");
        }

        input.close();
    }
}