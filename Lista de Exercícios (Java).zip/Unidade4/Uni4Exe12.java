/*
 * Dados 3 valores lado1, lado2, lado3, que representam os comprimentos dos lados de um triângulo, 
 * descreva um algoritmo que verifique se os mesmos podem ser os comprimentos dos lados de um triângulo. 
 * Em caso afirmativo, verifique e informe se é "triângulo equilátero", 
 * "triângulo isósceles" ou "triângulo escaleno". 
 * Em caso negativo, informe que os mesmos não formam um triângulo. Considere que:

 * o comprimento de cada lado de um triângulo é menor que a soma dos comprimentos dos outros lados
 * um triângulo equilátero tem três lados iguais
 * um triângulo isóscele tem dois lados iguais e um diferente
 * um triângulo escaleno tem três lados diferentes
 */

import java.util.Scanner;

public class Uni4Exe12 {
    public static void main(String[] args) {

        // Entradas
        Scanner input = new Scanner(System.in);
        System.out.println("Digite um dos lados do triângulo: ");
        int lado1 = input.nextInt();
        System.out.println("Digite um dos lados do triângulo: ");
        int lado2 = input.nextInt();
        System.out.println("Digite um dos lados do triângulo: ");
        int lado3 = input.nextInt();

        input.close();

        // Processo
        if (lado1 == lado2 && lado1 == lado3) {
            System.out.println("Este é um triângulo equilátero.");
        } else if (lado1 == lado2 && lado1 != lado3) {
            System.out.println("Este é um triângulo isósceles.");
        } else if (lado1 != lado2 && lado1 == lado3) {
            System.out.println("Este é um triângulo isósceles.");
        } else {
            System.out.println("Este é um triângulo escaleno.");
        }
    }

}
