/*
 * Dado um caractere indicando uma opção, escreva um algoritmo para:

se opção = ‘T’: calcular a área de um triângulo de base b e altura h
se opção = ‘Q’: calcular a área de um quadrado de lado l
se opção = ‘R’: calcular a área de um retângulo de base b e altura h
se opção = ‘C’: calcular a área de um círculo de raio r
 */

import java.util.Scanner;

public class Uni4Exe26 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Escolha uma opção:\n \'T\': calcular a área de um triângulo de base b e altura h\n" +
                " \'Q\': calcular a área de um quadrado de lado l\n \'R\': calcular a área de um retângulo de base b e altura h\n"
                +
                " \'C\': calcular a área de um círculo de raio r");
        char opcao = input.next().charAt(0);

        char opcaoValida = Character.toUpperCase(opcao);

        switch (opcaoValida) {
            case 'T':
                System.out.println("Digite a base de um triângulo: ");
                double base = input.nextDouble();
                System.out.println("Digite a altura de um triângulo: ");
                double altura = input.nextDouble();

                double areaTriangulo = (base * altura) / 2;
                System.out.println("Área do triângulo: " + areaTriangulo);
                break;
            case 'Q':
                Scanner quadrado = new Scanner(System.in);
                System.out.println("Digite o lado de um quadrado: ");
                double lado = quadrado.nextDouble();

                double areaQuadrado = lado * lado;
                System.out.println("Área do quadrado: " + areaQuadrado);
                break;
            case 'R':
                Scanner retangulo = new Scanner(System.in);
                System.out.println("Digite a base do retângulo: ");
                double b = retangulo.nextDouble();
                System.out.println("Digite a altura do retângulo: ");
                double h = retangulo.nextDouble();

                double areaRetangulo = b * h;
                System.out.println("Área do retângulo: " + areaRetangulo);
                break;
            case 'C':
                Scanner circulo = new Scanner(System.in);
                System.out.println("Digite o raio:");
                double raio = circulo.nextDouble();

                double areaCirculo = Math.PI * Math.pow(raio, 2);
                System.out.println("Área do círculo: " + areaCirculo);
            default:
                System.out.println("\nOpção inválida. Por favor, escolha uma das opções acima.");
                break;
        }

        input.close();
    }
}
