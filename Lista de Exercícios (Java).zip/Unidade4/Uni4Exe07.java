/*
 * O custo do selo de uma carta com até 50 gramas é de R$ 0,45. 
 * As cartas com peso superior pagam um adicional de R$ 0,45 por cada 20 gramas, 
 * ou fração, em que excedem aquele peso. Escreva um algoritmo que dado o peso da carta, 
 * em gramas, determine o custo do selo.
 */

import java.util.Scanner;

public class Uni4Exe07 {
    public static void main(String[] args) {

        // Entradas
        Scanner input = new Scanner(System.in);
        System.out.println("Entre com o peso da carta: ");
        double peso = input.nextDouble();

        input.close();

        // Declaração de variáveis
        double valorPagar = 0;
        double pesoExcedido = peso - 50;
        double qtAdicional = (pesoExcedido / 20) + 1;

        // Processo e Entradas
        if (peso <= 50) {
            valorPagar = 0.45;
            System.out.println("Custo do selo: " + valorPagar);
        } else {
            valorPagar = (0.45 + 0.45) * qtAdicional;
            System.out.println("Custo do selo: " + valorPagar);
        }
    }
}
